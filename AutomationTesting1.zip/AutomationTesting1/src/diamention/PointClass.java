package diamention;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PointClass {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//launch url
		//driver.get("https://www.amazon.in/");
		
		//Navigate url
		
		driver.navigate().to("https://www.amazon.in/");
		
		//to maximize
		//driver.manage().window().maximize();
		
		//Set Position
		
		//Point p=new Point(500,500);
		//driver.manage().window().setPosition(p);
		
		Point a=driver.manage().window().getPosition();
		System.out.println(a);
		
		Point b=driver.manage().window().getPosition();
		System.out.println(b);
		
		

	}

}
