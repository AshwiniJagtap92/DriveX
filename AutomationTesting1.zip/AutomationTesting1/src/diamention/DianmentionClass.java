package diamention;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DianmentionClass {
	
	//Dimention- to check stability and position of web element

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//Navigate url
		
		driver.navigate().to("https://www.tradingview.com/");
		
		//to maximize
		driver.manage().window().maximize();
		
		//for default browser
		
		Dimension a=driver.manage().window().getSize();
		System.out.println(a);
		
		Dimension d=new Dimension(700, 758);
		driver.manage().window().setSize(d);
		
	
		
		
		driver.quit();
		
		
		
		
		 

	}

}
