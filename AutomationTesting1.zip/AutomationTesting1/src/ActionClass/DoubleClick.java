package ActionClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DoubleClick {

	
		public static void main(String[] args) {
			System.setProperty("webdriver.chrome.driver",
					"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://api.jquery.com/dblclick/");
			driver.manage().window().maximize();
			driver.switchTo().frame(0);
			WebElement box = driver.findElement(By.xpath("/html/body[1]/div[1]"));

			Actions act = new Actions(driver);
			act.doubleClick(box).build().perform();
		

	}

}
