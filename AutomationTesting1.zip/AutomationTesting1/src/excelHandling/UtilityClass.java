package excelHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UtilityClass
{
	String path="C:\\Users\\Ashwini\\eclipse-workspace\\AutomationTesting1\\src\\excelHandling\\ExcelFileFolder\\Ex2.xlsx";

	File file;
	FileInputStream fis;
	XSSFWorkbook wb;
	XSSFSheet sheet;
	public String readData(int sheet_index,int rownum,int cellnum) throws
	IOException
	{
	file = new File(path);
	fis = new FileInputStream(file);
	wb = new XSSFWorkbook(fis);
	sheet = wb.getSheetAt(sheet_index);
	String data =
	sheet.getRow(rownum).getCell(cellnum).getStringCellValue();
	return data;
	}
	public void writeData(int sheet_index,int rownum,int cellnum,String status)
	throws IOException
	{
	file = new File(path);
	fis = new FileInputStream(file);
	wb = new XSSFWorkbook(fis);
	sheet = wb.getSheetAt(sheet_index);
	sheet.getRow(rownum).createCell(cellnum).setCellValue(status);
	FileOutputStream fos = new FileOutputStream(file);
	wb.write(fos);
	wb.close();
	
		
	}	

	}


