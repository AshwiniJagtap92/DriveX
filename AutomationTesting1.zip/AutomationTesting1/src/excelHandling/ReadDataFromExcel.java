package excelHandling;

import java.io.IOException;

public class ReadDataFromExcel
{

	public static void main(String[] args) throws IOException
	{
		UtilityClass util = new UtilityClass();
		String data11 = util.readData(0, 1, 0);
		System.out.println(data11);
		util.writeData(0, 1, 2, "Pass");
	}

}
