package excelHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelExample {

	public static void main(String[] args) throws IOException 
	{
		//provide path of excel sheet
		String 	path=("E:\\Testing\\amarsir\\ApachePOI\\ExcelFile\\example1.xlsx");
		
		//create object of file class
		File fl=new File(path);
		
		//create object of file inputstream
		FileInputStream fis=new FileInputStream(fl);
		
		//create object of XSSFWorkbook
		
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		
		//create object of sheet
		XSSFSheet sheet=wb.getSheetAt(0);
		
		//create object of row
		XSSFRow row=sheet.getRow(0);
		
		//create object of cell
		XSSFCell cell=row.getCell(0);
		
		//gain value
		String  value=cell.getStringCellValue();
		System.out.println(value);
		
		
	}

}
