package excelHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExcelExample3 {

	public static void main(String[] args) throws IOException 
	{
		String path="C:\\Users\\Ashwini\\eclipse-workspace\\AutomationTesting1\\src\\excelHandling\\ExcelFileFolder\\example1.xlsx";
		
		File file=new File(path);
		
		FileInputStream fis=new FileInputStream(file);
		
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		
		//create object of sheet
		XSSFSheet sheet=wb.getSheetAt(0);
		
		String Data00=sheet.getRow(1).getCell(0).getStringCellValue();
		String Data11=sheet.getRow(1).getCell(1).getStringCellValue();
		
		System.out.println(Data00);
		System.out.println(Data11);
		
	//**************************************************************************************//	
		
			/*	System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				driver.get("https://www.saucedemo.com/");
				driver.manage().window().maximize();
				
	//*****************************************			
				
				driver.findElement(By.id("user-name")).sendKeys(Data00);
				driver.findElement(By.id("password")).sendKeys(Data11);
				driver.findElement(By.id("login-button")).click();  */
		
		
		//write status of test cases from excel sheet
		
		sheet.getRow(1).createCell(2).setCellValue("pass");
		sheet.getRow(2).createCell(2).setCellValue("fail");
		FileOutputStream fos=new FileOutputStream(file);
		
		//now actual write
		wb.write(fos);
		wb.close();
		
		System.out.println("Data Updated sucessfully");
		
	}

}
