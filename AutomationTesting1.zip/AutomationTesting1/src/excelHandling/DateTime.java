package excelHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Date;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DateTime {

	public static void main(String[] args) throws IOException {
		//provide path of excel sheet
		
		
		 String path = "C:\\Users\\Ashwini\\eclipse-workspace\\AutomationTesting1\\src\\excelHandling\\ExcelFileFolder\\Ex2.xlsx";
		
		//create object of file class
		File fl=new File(path);
		
		//create object of file inputstream
		FileInputStream fis=new FileInputStream(fl);
		
		//create object of XSSFWorkbook
		
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		
		//create object of sheet
		XSSFSheet sheet=wb.getSheetAt(0);
		
		LocalDateTime Data=sheet.getRow(0).getCell(1).getLocalDateTimeCellValue();
		System.out.println(Data);
		

	}

}
