package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RelativeXpathExample1 {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", 
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//url launch
		
		driver.get("https://www.facebook.com/reg/");
		
		//to maximize
		
		driver.manage().window().maximize();
		
		//for first name-----@name----Relative Xpath
		
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Ashwini");
		
		//for last name----w.t.h.o.class
		
		//driver.findElement(By.xpath("//input[@class='inputtext _58mg _5dba _2ph-']")).sendKeys("Jagtap");
		
		driver.findElement(By.xpath("(//input[@class='inputtext _58mg _5dba _2ph-'])[2]")).sendKeys("Miller");
		
		
		
	}

}
