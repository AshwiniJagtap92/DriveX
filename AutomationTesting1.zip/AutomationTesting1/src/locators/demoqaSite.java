package locators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demoqaSite {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromerdriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//launch url
		driver.get("https://www.facebook.com/");
		
		//to maximize
		
		driver.manage().window().maximize();

	}

}
