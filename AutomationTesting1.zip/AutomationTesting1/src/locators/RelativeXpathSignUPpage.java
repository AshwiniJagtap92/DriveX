package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RelativeXpathSignUPpage {

	public static void main(String[] args) 
	
	{
		
			System.setProperty("webdriver.chrome.driver", 
					"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
			
			WebDriver driver=new ChromeDriver();
			
			//url launch
			
			driver.get("https://www.facebook.com/");
			
			//to maximize
			
			driver.manage().window().maximize();
			
			//for Email Address----Relative Xpath
			
			driver.findElement(By.xpath("//input[@name='email']")).sendKeys("jagtapashu2222@gmail.com");
			
			
          //for password----Relative Xpath
			
			driver.findElement(By.xpath("//input[@name='pass']")).sendKeys("test@1234");
			
			//for login
			

			
			driver.findElement(By.xpath("//button[@class='_42ft _4jy0 _52e0 _4jy6 _4jy1 selected _51sy']")).click();
			
			
			
			
	}

}
