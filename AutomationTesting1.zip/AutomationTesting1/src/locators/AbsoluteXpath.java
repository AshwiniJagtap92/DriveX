package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AbsoluteXpath {

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//url launch
		
		driver.get("https://www.way2automation.com/way2auto_jquery/registration.\r\n"
				+ "php#load_box");
		
		//for first name - absolute xpath
		
		driver.findElement(By.xpath("/html/body/section/div[1]/div/div/form/fieldset/p/input")).sendKeys("Ashwini");
		
		
		//for last name// absolute xpath
		
		driver.findElement(By.xpath("/html/body/section/div[1]/div/div/form/fieldset/p[2]/input")).sendKeys("Jagtap");
		
		//for close perticular tab
		//driver.quit();
	

	}

}
