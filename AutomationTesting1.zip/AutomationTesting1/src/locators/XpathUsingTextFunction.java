package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathUsingTextFunction {

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\\\Testing\\\\amarsir\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		//url launch
		
	driver.get("https://www.flipkart.com/");
	//maximize
	
	driver.manage().window().maximize();
	
	//using text function
	driver.findElement(By.xpath("//button[@class='_2KpZ6l _2doB4z']")).click();
	
	//using text links
	
	driver.findElement(By.xpath("//div[text()='Appliances']")).click();
	
    //using text link
	
	driver.findElement(By.xpath("//div[text()='Mobiles']")).click();
	
	//using text link
	
	//driver.findElement(By.xpath("//div[text()='Grocery']")).click();
	
	driver.findElement(By.xpath("//div[contains(text(),'Gro')]")).click();

	
	
	
	}

}
