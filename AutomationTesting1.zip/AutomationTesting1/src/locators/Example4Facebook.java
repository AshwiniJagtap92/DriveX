package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Example4Facebook {

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		ChromeDriver driver=new ChromeDriver();
		
		//url launch
		
		driver.get("https://www.facebook.com/");
		
		//maximize
		
		driver.manage().window().maximize();
		
		//username
		
		driver.findElement(By.id("email")).sendKeys("Ashwini9823@gmail.com");
		
		//password
		
		driver.findElement(By.name("pass")).sendKeys("test123");
		
		//login
		
		//driver.findElement(By.name("login")).click();
		
		//forgotton pass
		
		driver.findElement(By.partialLinkText("gotten pass")).click();

		
		
		
	}

}
