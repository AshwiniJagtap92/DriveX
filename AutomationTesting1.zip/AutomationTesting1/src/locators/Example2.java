package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Example2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", 
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
        ChromeDriver driver=new ChromeDriver();
        
        //url launch
        
        driver.get("https://www.amazon.in");
        
        //maximize window
        
        driver.manage().window().maximize();
        
        //to search box by id
        
      WebElement ref=  driver.findElement(By.id("twotabsearchtextbox"));
      
      ref.sendKeys("iphone");
      
      
      //to search button
      
    WebElement search_btn=  driver.findElement(By.id("nav-search-submit-button"));
    
    search_btn.click();
      
        
        
        
	}

}
