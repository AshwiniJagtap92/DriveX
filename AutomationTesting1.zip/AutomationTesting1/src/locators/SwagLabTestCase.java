package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwagLabTestCase {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		
		WebDriver driver=new ChromeDriver();
		
		//launch url
		
		driver.get("https://www.saucedemo.com/");
		
		//maximize window
		
		driver.manage().window().maximize();
		
		//username
		
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		
		//password
		
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		
		//logged in
		
		driver.findElement(By.id("login-button")).click();
		
		//click on menu button
		driver.findElement(By.id("react-burger-menu-btn")).click();
		
		//click on about button
		//driver.findElement(By.id("about_sidebar_link")).click();
		
		Thread.sleep(1000);
		//click on logout
		driver.findElement(By.id("logout_sidebar_link")).click();
		
		
		

	}

}
