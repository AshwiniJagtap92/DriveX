package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Example1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", 
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		
		//launch url
		driver.get("https://automationpractice.com/index.php");
		
		//maximize window
		
		driver.manage().window().maximize();
		
		//id
		
		WebElement ref=driver.findElement(By.id("search_query_top"));
		ref.sendKeys("printed dress");
		
		//name search button
		
		WebElement Search_btn=driver.findElement(By.name("submit_search"));
		
		Search_btn.click();
			
	}

}
