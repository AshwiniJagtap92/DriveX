package locators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ex {

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//launch url
		//driver.get("https://www.amazon.in/");
		
		//Navigate url
		
		driver.navigate().to("https://www.amazon.in/");
		
		//to maximize
		driver.manage().window().maximize();
		
		//refresh
		driver.navigate().refresh();
		
		//forward
		driver.navigate().forward();
		
		//backword
		driver.navigate().back();


	}

	private static Object Navigate() {
		// TODO Auto-generated method stub
		return null;
	}

}
