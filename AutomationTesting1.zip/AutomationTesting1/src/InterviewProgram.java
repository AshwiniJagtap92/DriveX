
public class InterviewProgram 
{

	public static void main(String[] args) 
	{
		int [] num= {1,2,1,2,3,4};
		
		System.out.println(num[0]);
		System.out.println(""+num[1]);
		
		

	}

}
