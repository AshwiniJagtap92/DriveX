package javaScriptExucator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Jscript {

	
		public static void main(String[] args)
		{
			System.setProperty("webdriver.chrome.driver","E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://www.amazon.com/");
			driver.manage().window().maximize();
			
			Point xyz = driver.findElement(By.xpath("//a[text()='Amazon Currency Converter']")).getLocation();
					System.out.println(xyz);
					
					int x = xyz.getX();
					int y = xyz.getY();
					System.out.println(x+" "+y);
					
					JavascriptExecutor js=(JavascriptExecutor)driver;
					js.executeScript("window.scrollBy(0,1000)", "");
	}
		

}
