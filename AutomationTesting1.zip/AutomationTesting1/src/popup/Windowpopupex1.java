package popup;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Windowpopupex1 {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				driver.get("https://www.amazon.in/");
				driver.manage().window().maximize();
				
				
				driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("macbook pro"+Keys.ENTER);
				//click on 2nd page
				
				driver.findElement(By.xpath("//span[contains@class,'a-size-medium a-color-base a-text-normal]")).click();
				
				
				//for parent id
				String parentid=driver.getWindowHandle();
				
				//for childs id
				Set<String> childid = driver.getWindowHandles();
				
				System.out.println(parentid);
				System.out.println(childid);
				
				
				
				
		
	}

}
