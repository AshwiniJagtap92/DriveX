package popup;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowPopup
{
	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();

		driver.findElement(By.xpath("//button[@class='_2KpZ6l _2doB4z']")).click();
		driver.findElement(By.xpath("//input[@class='_3704LK']")).sendKeys("samsung"+Keys.ENTER);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[text()='SAMSUNG Galaxy F22 (Denim Blue, 64 GB)']")).click();
		String pid = driver.getWindowHandle();
		Set<String> cid = driver.getWindowHandles();
		
		System.out.println(pid);
		
		for(String id:cid)
		{
			System.out.println(id);
			if(!(id.equals(pid)))
			{
				driver.switchTo().window(id);
				driver.findElement(By.xpath("//button[@class='_2KpZ6l _2U9uOA _3v1-ww']")).click();
				
			}
			
		}
	}
}

