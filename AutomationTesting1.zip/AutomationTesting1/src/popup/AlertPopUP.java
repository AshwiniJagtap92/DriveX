package popup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertPopUP {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				driver.get("https://demoqa.com/alerts");
				driver.manage().window().maximize();
				
				//simple popup
				driver.findElement(By.xpath("//button[@id='alertButton']")).click();
				Thread.sleep(2000);
				driver.switchTo().alert().accept();
				
				Thread.sleep(2000);
				
				//confirmation popup
				driver.findElement(By.xpath("//button[@id='confirmButton']")).click();
				String abc=driver.switchTo().alert().getText();
				System.out.println(abc);
				driver.switchTo().alert().dismiss();
				
				Thread.sleep(2000);
				
				//
				
				driver.findElement(By.xpath("//button[@id='promtButton']")).click();
				driver.switchTo().alert().sendKeys("Ashwini");
				driver.switchTo().alert().accept();
				//driver.switchTo().alert().sendKeys("Ashwini");
				
				
			  
			
		
	}

}
