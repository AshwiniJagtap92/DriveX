package string;

public class Example5 {

	public static void main(String[] args) 
	{
		String a = "Mumbai";
		String b = "mumbai";
		String c = new String("mumbai");
		//==
		System.out.println(a==b);
		System.out.println(a==c);
		//equals
		System.out.println(a.equals(b));
		System.out.println(a.equals(c));
		//compare to
		System.out.println(a.compareTo(b));
		System.out.println(a.compareTo(c));

	}

}
