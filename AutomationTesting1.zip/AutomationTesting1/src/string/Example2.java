package string;

public class Example2 {

	public static void main(String[] args)
	{
		String dia = "Hum Jahan Khade Ho Jaate Hain, Line Wahi Se Shuru Hoti Hain";
				//int l =dia.length();
				//System.out.println(l);
				//char c1= dia.charAt(20);
				//System.out.println(c1);
				for(int i=0;i<l;i++)
				{
				char c2= dia.charAt(i);
				System.out.println(c2);
				}
				}


	}


