package string;

public class StringExample1 {

	public static void main(String[] args)
	{
		String name = "Shivlila";
		String name1 = new String("Shivlila");
		System.out.println(name);
		System.out.println(name1);

	}

}
