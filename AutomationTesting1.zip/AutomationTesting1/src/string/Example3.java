package string;

public class Example3 {

	public static void main(String[] args) {
		String movie = "Dil to Pagal hai";
		String s1= movie.toUpperCase();
		System.out.println(s1);
		String s2 = s1.toLowerCase();
		System.out.println(s2);
		String c1 = "mumbai";
		String c2 = "MUMbai";
		boolean z1= c1.equals(c2);
		System.out.println(z1);
		boolean z2 = c1.equalsIgnoreCase(c2);
		System.out.println(z2);

	}

}
