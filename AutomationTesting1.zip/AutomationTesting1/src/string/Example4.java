package string;

public class Example4 {

	public static void main(String[] args)
	{
		String college = " Collge of Engineering ";
		System.out.println(college);
		String a1 = college.trim();
		System.out.println(a1);
		}


	}


