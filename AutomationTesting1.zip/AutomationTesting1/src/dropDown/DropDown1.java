package dropDown;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ISelect;
import org.openqa.selenium.support.ui.Select;

public class DropDown1 {

	private static final String Select = null;

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//launch url
		//driver.get("https://www.amazon.in/");
		
		//Navigate url
		
		driver.navigate().to("https://www.amazon.in/");
		
		//to maximize
		driver.manage().window().maximize();
		
		 WebElement xyz=driver.findElement(By.xpath("//select[@id='searchDropdownBox']"));
		 
		 Select s=new Select(xyz);
		 
		 //by index
		 s.selectByIndex(5);
		 
		 //by value
		s.selectByValue("search-alias=alexa-skills");
		
		//by text
		s.selectByVisibleText("Amazon Devices");
		
		//count of all options
		List<WebElement> all_options=s.getOptions();
		int count=all_options.size();
		 System.out.println(count);
		 
		 //print all options from index
		 
		 for(int i=0;i<count;i++)
		 {
			 String data=all_options.get(i).getText();
					 System.out.println(data);
		 }
		 
		
		
		//day
		//WebElement day =driver.findElement(By.id("//select[@id='day']"));
		//Select s1 = new Select(day);
		//s1.selectByIndex(1);

		

	}

	
}
