package screenshot;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Screenshott {

	public static void main(String[] args) throws IOException 
	{
		
		System.setProperty("webdriver.chrome.driver", 
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//launch url
		driver.get("https://www.google.com/");
		
		//maximize window
		driver.manage().window().maximize();
		
		
		
		//ScreenShot
		//using interface and type casting
		
		TakesScreenshot ts=(TakesScreenshot)driver;
		
		//provide src path
		
		File src=ts.getScreenshotAs(OutputType.FILE);
		
		//provide destination path
		
		File des=new File("E:\\Testing\\amarsir\\Selenium\\Screenshot\\google1.png");
		
		//move screenshot from src to des
		
		FileHandler.copy(src, des);
		
		//------------------------------------------------------
		
		System.out.println("Screenshot Captured");
		
		
		
		
		
		

	}

}
