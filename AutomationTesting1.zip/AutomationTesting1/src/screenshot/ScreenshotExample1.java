package screenshot;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class ScreenshotExample1 {

	public static void main(String[] args) throws IOException 
	
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//launch url
		driver.navigate().to("https://www.google.com/");
		
		//maximize
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys("India"+Keys.ENTER);
		//captured screenshot
		TakesScreenshot ts=(TakesScreenshot)driver;
		
		//take screenshot and stored into internal memory
		File src=ts.getScreenshotAs(OutputType.FILE);
		
		String path="C:\\Users\\Ashwini\\eclipse-workspace\\AutomationTesting1\\src\\screenshot\\screenshotimages\\";
		
		//provide destination location
		File des=new File(path+"india.png");
		
		FileHandler.copy(src, des);
		
		
		
		
		

	}

}
