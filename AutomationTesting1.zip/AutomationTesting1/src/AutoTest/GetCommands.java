package AutoTest;

import org.openqa.selenium.chrome.ChromeDriver;

public class GetCommands {

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", 
				"E:\\\\Testing\\\\amarsir\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe");
		
		ChromeDriver driver=new ChromeDriver();
		
		//Launch Url - To launch url in browser
		
		driver.get("https://www.amazon.com/");
		
		//get title -to get title of the page
		
		String title=driver.getTitle();
		System.out.println(title);
		
		//current url - to get url of current page
		
	  String currenturl=driver.getCurrentUrl();
	  System.out.println(currenturl);
	  
	  //view page source - to get html code of the page
	  
	  String getpagesrc=driver.getPageSource();
	  System.out.println(getpagesrc);
	  
	  
	
	
	
	
	
		
	}

}
