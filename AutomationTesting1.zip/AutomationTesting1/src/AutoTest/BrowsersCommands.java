package AutoTest;

//Browsers Command
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowsersCommands {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", 
				"E:\\\\Testing\\\\amarsir\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe");
		
		ChromeDriver driver=new ChromeDriver();
		
		//Launch Url
		
				driver.get("https://www.amazon.com/");
		
		//Maximize - to maximize your window
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		//Minimize - to minimize your window
		//driver.manage().window().minimize();
		
		//close - close perticulat tab (focus asel te)
		
		driver.close();
		
		//quit - to close all tabs
		driver.quit();
		
		
		
		
		
	}

}
