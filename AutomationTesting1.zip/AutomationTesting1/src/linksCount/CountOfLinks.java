package linksCount;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CountOfLinks {

	public static void main(String[] args) throws IOException, InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
				
				WebDriver driver = new ChromeDriver();
				driver.get("https://msrtc.maharashtra.gov.in/index.php/node/index/177");
				driver.manage().window().maximize();
				
				 List<WebElement>links=driver.findElements(By.tagName("a"));
				 
				 //number of links
				 System.out.println(links.size());
				 
				 for(int i=0;i<links.size();i++)
			        {
			            WebElement E1= links.get(i);
			            String url= E1.getAttribute("href");
			           URL link=new URL(url);
			           HttpURLConnection httpconn=(HttpURLConnection) link.openConnection();
			           Thread.sleep(20000);
			           httpconn.connect();
			           
			          int responsecode= httpconn.getResponseCode();
			          if(responsecode>=400)
			          {
			        	  System.out.println(url+"-"+"broken link");
			          }
			          else
			          {
			        	  System.out.println(url+"-"+"valid link");
			          }
			           
			        }

	}

}
