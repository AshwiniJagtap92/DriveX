package exceptationHandling;

public class TryCatchFinally {
	public static void main(String[] args) 
	{
		try
		{
			System.out.println("2");
			System.out.println(2/0);
		}
		
		catch(ArithmeticException A) //Child Exception
		{
			A.printStackTrace();
		}
		catch(Exception e)    //parent Exception
		{
			e.printStackTrace();
		}
		
		
		finally
		{
			System.out.print("code excucated");
		}
		

	}



}
