package exceptationHandling;

public class FinalTryCatchBlock {

	public static void main(String[] args)
	{
		try {
			int a = 10;
			int b = 0;
			int c = a/b;
		    System.out.println(c);
		}
		
		catch(Exception f) 
		{
			f.printStackTrace();  //Best and most preferred
			//ExceptionName
			//Description
			//StackTrace
			
			System.out.println("=========");
			
			System.out.println(f);
			//ExceptionName
			//Description
			
            System.out.println("=========");
			
			System.out.println(f.getMessage());
			//Description
			
			
			
		}

	}
		

	}


