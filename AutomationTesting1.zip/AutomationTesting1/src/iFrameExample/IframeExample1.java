package iFrameExample;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class IframeExample1 {

	public static void main(String[] args) throws IOException
	
	{
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//launch url
		//driver.get("https://www.amazon.in/");
		
		//Navigate url
		
		driver.navigate().to("file:///E:/Testing/amarsir/HTML/iframefinal.html");
		
		//to maximize
		driver.manage().window().maximize();
		
		//by index
		driver.findElement(By.xpath("//input[@id='1467']")).sendKeys("Ashwini");
	
		//switch focus from main page to iframe pagae
		driver.switchTo().frame(0);
		
		driver.findElement(By.xpath("//input[@id='13467']")).sendKeys("Pune");
		
		//switch focus from iframe to main page
		driver.switchTo().defaultContent();
		
		driver.findElement(By.xpath("//input[@id='13']")).sendKeys("Jagtap");
		
		
		//screenshot
		
		TakesScreenshot ts=(TakesScreenshot)driver;
		
		//stored screenshot into source 
		File src=ts.getScreenshotAs(OutputType.FILE);
		
		//destination path
		File des=new File("E:\\Testing\\amarsir\\Selenium\\Screenshot\\regi.png");
		
		//move file from src to destination
		
		FileHandler.copy(src, des);
		
		//------------------------------------
		
		System.out.println("screenshot captured");
		
		
	}

}
