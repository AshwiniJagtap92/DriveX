package iFrameExample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Iframe {

	public static void main(String[] args)
	{
		
		System.setProperty("webdriver.chrome.driver",
				"E:\\Testing\\amarsir\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		//launch url
		//driver.get("https://www.amazon.in/");
		
		//Navigate url
		
		driver.navigate().to("file:///E:/Testing/amarsir/HTML/iframefinal.html");
		
		//to maximize
		driver.manage().window().maximize();
		
		//for username
		driver.findElement(By.xpath("//input[@id='1467']")).sendKeys("Ashwini");
		
		//switch the focus of from main page to frame
		driver.switchTo().frame(0);
		//for city name
		driver.findElement(By.xpath("//input[@id='13467']")).sendKeys("Pune");
		
		//switch foucs from frame to main page
		driver.switchTo().defaultContent();
		
		//last name
		
		driver.findElement(By.xpath("//input[@id='13']")).sendKeys("Jagtap");
		
		//switch the focus of from main page to frame
		driver.switchTo().frame(0);
		
		//Mobile Number
		driver.findElement(By.xpath("//input[@id='153']")).sendKeys("9860880998");

	}

}
